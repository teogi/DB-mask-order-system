<?php
  session_start();
  if(!isset($_SESSION['UserID'])){
    header("Location: index.php");
    exit();
 }
  $dbservername ='localhost';
  $dbname  ='order_sys';
  $dbusername ='examdb';
  $dbpassword ='examdb';
  $conn = new PDO("mysql:host=$dbservername;dbname=$dbname", $dbusername, $dbpassword);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $id=$_SESSION['UserID'];
  $name=$_SESSION['Username'];
  $select_shop="";
  if (isset($_POST['shop'])){
   if($_POST['shop']!='All') $select_shop .="and shop_name='".$_POST['shop']."'";
  }
  if(isset($_POST['status'])){
   $ord_status=array("Not Finished"=>0,"Finished"=>1,"Cancelled"=>2);
   $select_shop .="and status=".$ord_status[$_POST['status']];
  }
  //echo $select_shop;
  if(isset($_POST['done_id'])){
   $query="update orders set status=:status where oid=:oid";
   $stmt=$conn->prepare($query);
   $stmt->execute(array(':status'=>1, ':oid'=>$_POST['done_id']));
   
   $query="update orders set finisher=:name where oid=:oid";
   $stmt=$conn->prepare($query);
   $stmt->execute(array(':name'=>$name, ':oid'=>$_POST['done_id']));
   
   $query="update orders set finish_date=NOW() where oid=:oid";
   $stmt=$conn->prepare($query);
   $stmt->execute(array(':oid'=>$_POST['done_id']));
   //echo "you clicked done!!!<br>";
  }
  if(isset($_POST['cancel_id']) && isset($_POST['cancel_amount'])){
   //set_status to cancelled
   $query="update orders set status=:status where oid=:oid";
   $stmt=$conn->prepare($query);
   $stmt->execute(array(':status'=>2, ':oid'=>$_POST['cancel_id']));
   
   //ajsust mask amount
   $query="select mask_amount from shop NATURAL JOIN orders where oid=:oid";
   $stmt=$conn->prepare($query);
   $stmt->execute(array(':oid'=>$_POST['cancel_id']));
   $row = $stmt->fetch();
   $new_amount=$row['mask_amount']+$_POST['cancel_amount'];
   /*echo "new amount: ";
   echo $new_amount;*/
   $query="update shop set mask_amount=:mask_amount where oid=:oid";
   $stmt=$conn->prepare($query);
   $stmt->execute(array(':mask_amount'=>$new_amount, ':oid'=>$_POST['cancel_id']));
  }
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $_SESSION['SName'] ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
<nav class="navbar navbar-expand-sm bg-light navbar-light sticky-top">
	<ul class="navbar-nav">
		<li class="nav-item"><a class="nav-link" href="home.php" id="home">Home</a></li>
		<li class="nav-item"><a class="nav-link" href="shop.php" id="shop">Shop</a></li>
		<li class="nav-item"><a class="nav-link" href="my_order.php"  id="my_order">My Order</a></li>
		<li class="nav-item active"><a class="nav-link" href="#"  id="shop_order">Shop Order</a></li>
		<li class="nav-item"><a class="nav-link" href="logout.php" id="Logout">Logout</a></li>
	</ul>
</nav>
<form action="shop_order.php" method="post">
 Shop<select name="shop">
     <option value="All">All</option>
     <?php
      $stmt=$conn->prepare("select distinct shop_name from shop NATURAL JOIN work_for where username=:username or mid=:mid");
      $stmt->execute(array(':username'=>$name,':mid'=>$id));
       while(!empty($row=$stmt->fetch())){
        echo "<option value='".$row['shop_name']."'>".$row['shop_name']."</option>";
       }
     ?>
 </select>
 <br>
 Status<select name="status">
  <option value="Not Finished">Not Finished</option>
  <option value="Finished">Finished</option>
  <option value="Cancelled">Cancelled</option>
 </select>
 <br>
 <input type="submit" value="Search">
</form>

<table class="table">
<thead>  
  <tr>
    <th></th>
    <th>OID</th>
    <th>Status</th>
	<th>Start</th>
	<th>End</th>
	<th>Shop</th>
	<th>Total Price</th>
	<th>Action</th>
  </tr>
</thead>
<?php
  $status=array(0=>"Not Finished", 1=>"Finished", 2=>"Cancelled");
  $query="SELECT distinct oid,status,start_date,orderer ,finish_date, finisher, shop_name, price, mid,amount
  FROM  orders NATURAL JOIN shop NATURAL JOIN work_for where ( mid=:mid or username=:username ) ".$select_shop;
  //echo $query;
  $stmt=$conn->prepare($query);
  $stmt->execute(array(':mid'=>$id, ':username'=>$name));
?>
 
 <form class='' id='multi' method='post'>
  <input type='submit' value='Finish Selected' formaction='f_order.php'></input>
 </form>
 
 <?php
 $arr_i=1;
 $oid=$row['oid'];
  while(!empty($row=$stmt->fetch())){
   echo "<td>".($status[$row['status']]=="Not Finished" ?
   "<input type='checkbox' name='oid[]' id= 'oid$arr_i' value=$oid form='multi'>":
    "")."</td>";
   echo "<td>".$row['oid']."</td>";
   echo "<td>".$status[$row['status']]."</td>";
   echo "<td>".$row['start_date']."<br>".$row['orderer']."</td>";
   echo "<td>".$row['finish_date']."<br>".$row['finisher']."</td>";
   echo "<td>".$row['shop_name']."</td>";
   $total_price=$row['price']*$row['amount'];
   echo "<td>".$total_price. "<br>(". $row['price']. "*". $row['amount']. ")</td>";
   if($status[$row['status']]=="Not Finished"){
    echo "<td>";
	echo "<form action='shop_order.php' method='post'>";
    echo 	"<input type='hidden' name='done_id' value=".$row['oid'].">";
    echo 	"<input type='submit' value='Done'>";
	echo "</form>";
	echo "<form action='shop_order.php' method='post'>";
    echo 	"<input type='hidden' name='cancel_id' value=".$row['oid'].">";
    echo 	"<input type='hidden' name='cancel_amount' value=".$row['amount'].">";
    echo 	"<input type='submit' value='Cancel'>";
	echo "</form>";
	echo "</td>";
   }
   echo "</tr>";
   $arr_i++;
  }
  ?>
 
  <?php
 unset($_POST['done_id']);
 unset($_POST['cancel_id']);
 unset($_POST['cancel_amount']);
  ?>
</table>
</body>
</html>