<?php
  session_start();
  if(!isset($_SESSION['UserID'])){
    header("Location: index.php");
    exit();
 }
  $dbservername	='localhost';
  $dbname		='order_sys';
  $dbusername	='examdb';
  $dbpassword	='examdb';
  $mid=$_SESSION['UserID'];
  $conn = new PDO("mysql:host=$dbservername;dbname=$dbname", $dbusername, $dbpassword);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  if (isset($_POST['mask_price'])){
	$stmt=$conn->prepare("UPDATE shop SET mask_price=:mask_price WHERE mid=:mid");
	$stmt->execute(array('mask_price'=>$_POST['mask_price'], 'mid'=>$mid));
	header("Location: shop.php");
  }
  if (isset($_POST['mask_amount'])){
    $stmt=$conn->prepare("UPDATE shop SET mask_amount=:mask_amount WHERE mid=:mid");
	$stmt->execute(array('mask_amount'=>$_POST['mask_amount'], 'mid'=>$mid));
	header("Location: shop.php");
  }
  if (isset($_POST['account'])){
	 $stmt=$conn->prepare("SELECT username FROM work_for  WHERE username=:account");
	 $stmt->execute(array('account'=>$_POST['account']));
	 if ($stmt->rowCount()==1){
		  $_SESSION['add_error']="{$_POST['account']} is already an employee at {$_SESSION['SName']}";
		  header("Location: shop_manager.php");
		  exit();
	 }
	 $stmt=$conn->prepare("SELECT * FROM user WHERE username=:account");
	 $stmt->execute(array('account'=>$_POST['account']));
	 if ($stmt->rowCount()==0){
		  $_SESSION['add_error']='No such user!';
		  header("Location: shop_manager.php");
		  exit();
	 }
	 $row = $stmt->fetch();
	 if($row['uid']==$mid){
		  $_SESSION['add_error']='You CANNOT add yourself!';
		  header("Location: shop_manager.php");
		  exit();
	 }
	  $stmt=$conn->prepare("INSERT INTO work_for (username,sid) VALUES(:account,:sid)");
	  $stmt->execute(array('account'=>$_POST['account'], 'sid'=>$_SESSION['SID']));
  }
  if(isset($_POST['delete'])){
		$stmt=$conn->prepare("delete FROM work_for WHERE username=:account");
		$stmt->execute(array('account'=>$_POST['delete']));
	}
 ?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $_SESSION['SName'] ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
<nav class="navbar navbar-default">
	<ul class="nav navbar-nav">
		<li><a href="home.php" class="button" id="home">Home		</a></li>
		<li><a href="#" class="button" id="shop">Shop				</a></li>
		<li><a href="logout.php" class="button" id="Logout">Logout	</a></li>
	</ul>
</nav>

<table>
	<tr>
		<th>Shop</th>
		<td><?php echo $_SESSION['SName']; ?></td>
	</tr>
	<tr>
		<th>City</th>
		<td><?php echo $_SESSION['City'];  ?></td>
	</tr>
	<tr>
		<th>Price</th>
		<td>
			<form action="shop_manager.php" method="post">
				<input type="text" name="mask_price" value="<?php echo $_SESSION['Price']; ?>">
				<input type="submit" value="Edit">
			</form>
		</td>
	</tr>
	<tr>
		<th>Quantity</th>
		<td>
			<form action="shop_manager.php" method="post">
				<input type="text" name="mask_amount" value="<?php echo $_SESSION['Quantity']; ?>">
				<input type="submit" value="Edit">
			</form>
		</td>
	</tr>
</table>

<br>
<form action="shop_manager.php" method="post">
  <label for="account">Employee</label>
  <input type="text" name="account" placeholder="Type Account"> 
  <input type="submit" value="ADD">
  <?php 
	if(isset($_SESSION['add_error'])) echo $_SESSION['add_error'];
  ?>
</form>



<table>
  <tr>
    <th>Account</th>
    <th>phone</th>
  </tr>
  <?php
	$stmt=$conn->prepare("SELECT username,phone FROM work_for NATURAL JOIN user WHERE sid=:sid");
	$stmt->execute(array(':sid'=>$_SESSION['SID']));
	while(!empty($row=$stmt->fetch())){
		echo "<tr>";
		echo "<td>".$row['username']."</td>";
		echo "<td>".$row['phone']."</td>";
		echo "<td><form action='shop_manager.php' method='post'>";
		echo "<input type='text' name='delete' value=".$row['username']." style='display:none;'>";
		echo "<input type='submit' value='Delete'>";
		echo "</form></td>";
		echo "</tr>";
	}
  ?>
</table>

<?php
	unset($_SESSION["add_error"]);
	$stmt=$conn->prepare("SELECT username FROM work_for  WHERE username=:account");
?>
</body>
</html>