<?php
session_start();

if($_SESSION['Authenticated']==false){
	session_unset();
	session_destroy();
	header("Location: index.php");
	exit();
}

$dbservername='localhost';
$dbname		='order_sys';
$dbusername	='examdb';
$dbpassword	='examdb';

class TableRows extends RecursiveIteratorIterator {
	function __construct($it) {
	parent::__construct($it, self::LEAVES_ONLY);
	}
	
	function current() {
	return "<td>" . parent::current(). "</td>";
	}
	
	function beginChildren() {
	echo "<tr>";
	}
	
	function endChildren() {
	echo "</tr>" . "\n";
	}
}

try
{
	/*
	if(!isset($_SESSION['Username'])){
		header("Location: index.php");
		exit();
	}
	*/
	
	//getting user profile information
	$uname	=$_SESSION['Username'];
	$phone	=$_SESSION['Phone'];
	$uid	=(int)$_SESSION['UserID'];
	$conn 	= new PDO("mysql:host=$dbservername;dbname=$dbname", 
					$dbusername, $dbpassword);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	/*
	$stmt=$conn->prepare("SELECT * FROM user where uname=:uname");
	$stmt->execute(array(':uname' => $uname));
	$row=$stmt->fetch();
	*/
	
	//shop searching list
	$op_stmt=$conn->prepare("SELECT DISTINCT city 
							FROM shop");
	$op_stmt->execute();
	
	
}
catch(Exception $e)
{
	$msg=$e->getMessage();
	session_unset();
	session_destroy();
	echo <<<EOT
		<!DOCTYPE html>
		<html>
			<body>
				<script>
					alert("$msg");
					window.location.replace("index.php");
				</script>
			</body>
		</html>
EOT;
}

//form error handling
$price_err="";
if(	$_SERVER["REQUEST_METHOD"]=="GET"&&isset($_GET['m_price_low']) &&
	isset($_GET['m_price_upp'])&&$_GET['m_price_low']			){
		if($_GET['m_price_low']>$_GET['m_price_upp'])
			$price_err="lower boundary should not be higher than upper boundary";
		elseif(!(preg_match("/^[0-9]*$/",$_GET['m_price_low']) &&
				 preg_match("/^[0-9]*$/",$_GET['m_price_upp'])	))
			$price_err="input should not contain any character than 0-9";
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
<nav class="navbar navbar-default">
	<ul class="nav navbar-nav">
		<li><a href="#" class="button" id="home">Home				</a></li>
		<li><a href="shop.php" class="button" id="shop">Shop		</a></li>
		<li><a href="logout.php" class="button" id="Logout">Logout	</a></li>
	</ul>
</nav>

<div class="profile">
	<h3 >Profile</h3>
	<table class='row table table-hover'>
		<tr>
			<td class='col-xs-2'>Account</td>
			<td class='col-xs-10'><?php echo $uname; ?></td>
		</tr>
		<tr >
			<td class='col-xs-2' >Phone</td>
			<td class='col-xs-10'><?php echo $phone; ?></td>
		</tr>
	</table>
</div>

<div class="shop_list">
	<form method="get">
		<label for="shop">Shop:</label>
		<input type="text" id="shop" name="shop"><br>
		<label for="city">City:</label>
		<select id="city" name="city">
			<option value="All">All</option>
			<?php
				$row=$op_stmt->fetch();
				if(!empty($row)){
					do {
						echo "<option value=\"". $row['city'] ."\">" .
							$row['city'] . '</option><br>';
					}while($row=$op_stmt->fetch());
				}
				
			?>
		</select><br>
		<label for="m_price_low m_price_upp">Mask Price:</label>
		<input type="text" id="m_price_low" name="m_price_low">~
		<input type="text" id="m_price_upp" name="m_price_upp">
		<span class="Error"><?php echo $price_err ?></span><br>
		<label for="m_amt">Mask Amount:</label>
		<select id="m_amt" name="m_amt"><br>
			<option value="All">All</option>
			<option value="0">0(sold)</option>
			<option value="1~50">1~50(few)</option>
			<option value="50~~">50 and above(many)</option>
		</select><br>
		<input type="checkbox" id="working" name="working">
		<label for="working">Only show the shop I work at</label>
		<br><input type="submit" value="Search">
	</form>
</div>

<div class="search_table ">
<?php
	if(	isset($_GET['shop'])	 	&&	isset($_GET['city'] ) && 
		isset($_GET['m_amt'])		&&	isset($_GET['m_price_low']) &&	
		isset($_GET['m_price_upp'])	&&  $price_err==""){ 
		$shop		= test_input($_GET['shop'] );
		$city		= test_input($_GET['city'] ); 
		$m_amt		= test_input($_GET['m_amt']	);
		$m_price_low= test_input($_GET['m_price_low'] );
		$m_price_upp= test_input($_GET['m_price_upp'] );
		
		try{
			//default w/ shop
			$query ="SELECT shop_name,city, mask_price,mask_amount 
					 FROM	shop ";
			$query.="WHERE 	shop_name LIKE :shop ";
			$param_arr= array(':shop'=>'%'.$shop.'%');
			if(isset($_GET['working'])){
				echo $_GET['working'];
				$query.=" AND mid=:uid";
				$param_arr[':uid']=$uid;
			}
			//city
			if($_GET['city']!='All'){
				$query.=' AND city = :city';
				$param_arr[':city']=$city;
			}
			
			//mask_price
			if(!empty($_GET['m_price_low'])&&!empty($_GET['m_price_upp'])){
				$query .= " AND mask_price BETWEEN :m_price_low AND :m_price_upp";
				$param_arr[':m_price_low']=$m_price_low;
				$param_arr[':m_price_upp']=$m_price_upp;
			}elseif(!empty($_GET['m_price_low'])){
				$query.=" AND mask_price >= :m_price_low";
				$param_arr[':m_price_low']=$m_price_low;
			}elseif(!empty($_GET['m_price_upp'])){
				$query.=" AND mask_price <= :m_price_upp";
				$param_arr[':m_price_upp']=$m_price_upp;
			}
			
			//mask_amount
			if($_GET['m_amt']=="0"){
				$query .= " AND mask_amount = 0";
			}
			elseif($_GET['m_amt']=='1~50'){
				$query .= " AND mask_amount BETWEEN 1 AND 50";
			}
			elseif($_GET['m_amt']=='50~~'){
				$query .= " AND mask_amount > 50";
			}
			
			$s_stmt=$conn->prepare($query);
			$s_stmt->execute($param_arr);
			
			echo "Total result shown: ".$s_stmt->rowCount();
			echo "<table class='table table-hover'>";
			echo "<tr><th>Shop</th><th>City</th><th>mask_price</th><th>mask_amount</th></tr>";

			$result = $s_stmt->setFetchMode(PDO::FETCH_ASSOC);
			foreach(new TableRows(new RecursiveArrayIterator($s_stmt->fetchAll())) as $k=>$v) {
				echo $v;
			}
			echo "</table>";
		}
		catch(PDOException $e){
			$errMsg=$e->getMessage();
			echo "Error:" . $errMsg;
		}
	}
	$conn = null;
?>
</div>
<!--
		<script>
			var option= ['All','Taipei','New Taipei','Keelung',
						'Taoyuan','Hsinchu','Yilan','Miaoli',
						'Taichung','Changhua','Nantou','Hualien',
						'Yunlin','Chiayi','Tainan','Kaohsiung',
						'Taitung','Pingtung','Penghu','Lienchiang'];
			
		</script>
-->
</body>
</html>

