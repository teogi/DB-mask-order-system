<?php
  session_start();
  $_SESSION['Authenticated']=false;
?>

<!DOCTYPE html>
<html>
<body>
	<h1>Login</h1>
	<form action="login.php" method="post">
		<input type="text" name="uname" placeholder="Username"><br>
		<input type="password" name="pwd" placeholder="Password"><br>
		<input type="submit" value="Login">
	</form>
	
	<h1>Create Account</h1>
	<form action="register.php" method="post">
	<input type="text" name="uname" placeholder="Username"><?php
	if(isset($_SESSION['name_error'])) echo $_SESSION['name_error'];
	?>
	<br>
	<input type="password" name="pwd" placeholder="Password"><?php
	if(isset($_SESSION['pwd_error'])) echo $_SESSION['pwd_error'];
	?>
	<br>
	<input type="password" name="cfm" placeholder="Comfirm password"><?php
	if(isset($_SESSION['cfm_error'])) echo $_SESSION['cfm_error'];
	?>
	<br>
	<input type="text" name="phone" placeholder="Phone number"><?php
	if(isset($_SESSION['pho_error'])) echo $_SESSION['pho_error'];
	?>
	<br>
	<input type="submit" value="Create Account">
	<?php if(isset($_SESSION['reg_suc']) && $_SESSION['reg_suc']==true){
				echo "Register success!";
				$_SESSION['reg_suc']=false;
		}
	?>
	</form>
</body>
</html>
<?php
	session_unset();
	session_destroy();
?> 